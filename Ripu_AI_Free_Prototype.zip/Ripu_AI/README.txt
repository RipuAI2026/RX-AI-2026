Ripu AI — Free mobile-friendly prototype

Included:
- index.html: responsive bilingual website
- Four template-based tools: story outline, video prompt, image prompt, voiceover script
- No API key needed for this first prototype

Important:
This version does NOT generate actual AI images, video, or audio. It creates useful prompt/script drafts in the browser. To add real AI generation later, connect a trusted provider through a server-side backend. Never place private API keys in public HTML/JavaScript.

How to preview on a phone:
1. Extract this ZIP or open index.html in a browser-capable HTML preview app.
2. For public hosting, create a GitHub repository, upload index.html, then enable GitHub Pages in repository Settings > Pages.
3. Wait for GitHub Pages to publish and open the URL shown there.
4. On GitHub's mobile website, some settings may be easier in the browser's desktop-site mode.

Free-first next steps:
- Customize logo, colors, and tool templates.
- Test Bengali and English.
- Later add real AI APIs using a backend; check each provider's pricing and free limits.
